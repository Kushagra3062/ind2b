import { ReportBuilder } from "@/components/admin/dashboard/reports/ReportBuilder"

export default function ReportsPage() {
  return <ReportBuilder />
}
