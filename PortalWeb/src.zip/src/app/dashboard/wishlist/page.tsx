import WishlistPage from "@/components/dashboard/WishlistPage"

export default function DashboardWishlistPage() {
  return <WishlistPage />
}
