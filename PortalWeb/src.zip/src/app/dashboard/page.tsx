import AccountSettings from "@/components/dashboard/AccountSettings"

export const dynamic = "force-dynamic"

export default function DashboardPage() {
  return <AccountSettings />
}
