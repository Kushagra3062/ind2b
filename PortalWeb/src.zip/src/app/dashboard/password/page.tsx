import PasswordPage from "@/components/dashboard/PasswordPage"

export default function DashboardPasswordPage() {
  return <PasswordPage />
}
